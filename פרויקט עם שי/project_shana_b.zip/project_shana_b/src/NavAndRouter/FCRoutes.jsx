import React from 'react'
import { Route, Routes } from 'react-router-dom'
import FCLogin from '../Pages/FCLogin'
import FCProfile from '../Pages/FCProfile'
import FCHomePage from '../Pages/FCHomePage'
import FCCars from '../Pages/FCCars'





export default function FCRoutes() {
    return (
        <div style={{ margin: 20, fontSize: 25, color: 'red' }}>
            <Routes>
                <Route path='/' element={<FCLogin />} />
                <Route path='/profile' element={<FCProfile />} />
                <Route path='/homepage' element={<FCHomePage />} />
                <Route path='/carstatistic' element={<FCCars />} />
            </Routes>
        </div>
    )
}
