import React, { useContext } from 'react'
import { Link } from 'react-router-dom';
import { UserContext } from '../Context/UserContextProvider';
import './Nav.css';

export default function FCNavbar() {
    const { loginOrProfile, adminIsConnect } = useContext(UserContext)

    return (
        <div className="navbar">
            <Link className="logo" to={"/"}>Login</Link>
            <div style={{marginLeft:"29%"}} className="navbar-right">
                {adminIsConnect && (
                    <>
                        <Link className="navbar a" to={"/profile"}>Users table</Link>
                        <Link className="navbar a" to={"/carstatistic"}>Cars table</Link>
                    </>
                )}
            </div>
        </div>
    )
}
//