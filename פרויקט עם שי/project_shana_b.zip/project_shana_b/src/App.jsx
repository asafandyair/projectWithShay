import './App.css';
import FCNavbar from './NavAndRouter/FCNav';
import FCRoutes from './NavAndRouter/FCRoutes';
import FCFooter from './Pages/FCFooter';

function App() {
  return (
    <div className="App">
      <FCNavbar />
      <header className="App-header">
        <FCRoutes />
      </header>
      <FCFooter/>
    </div>
  );
}

export default App;
