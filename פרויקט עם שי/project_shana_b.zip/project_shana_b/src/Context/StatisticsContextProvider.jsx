import React, { createContext, useEffect, useState } from 'react'

export const StatisticsContext = createContext()

export default function StatisticsContextProvider(props) {

  const [statisticsUsers, setStatisticsUsers] = useState(
    JSON.parse(localStorage.getItem('statisticsUsers')) ||
    [{ email: "asafnormalUser@gmail.com",username:"asafmahluf3", password: "1234567",userKind:"admin",gender:"male",phone:"052-6659555",birthDate:"13-07-1998",birthJoin:"04-05-2023",name: "Asaf" },
    { email: "yair@gmail.com",username:"yair161643", password: "1234567",userKind:"admin",gender:"male",phone:"052-16164300",birthDate:"13-07-1998",birthJoin:"04-05-2023",name: "yair" },
    { email: "shaykos@gmail.com",username:"shaykos", password: "1234567",userKind:"normal",gender:"female",phone:"052-97864521",birthDate:"13-07-1998",birthJoin:"04-05-2023",name: "shay" },]
  )



  useEffect(() => {
    const updateLocalStorage = () => {
      localStorage.setItem('statisticsUsers', JSON.stringify(statisticsUsers));
    };
    window.addEventListener('beforeunload', updateLocalStorage)
    return () => {
      window.removeEventListener('beforeunload', updateLocalStorage)
    };
  }, [statisticsUsers]);




  return (
    <StatisticsContext.Provider value={{ statisticsUsers }}>
      {props.children}

    </StatisticsContext.Provider>
  )
}





























