import React, { createContext, useEffect, useState } from 'react'

export const CarsContext = createContext()

export default function CarsContextProvider(props) {

    const [statisticsCars, setStatisticsCars] = useState(
        JSON.parse(localStorage.getItem('statisticsCars')) ||
        [
            { carNumber: "8191234", userCode: "123789", manufacurer: "Honda", model: "civic", year: "1999", km: "181,231", nickName: "Civicou" },
            { carNumber: "7654334", userCode: "6345664", manufacurer: "BMW", model: "3", year: "2018", km: "121,241", nickName: "hamudi" },
            { carNumber: "9876672", userCode: "7635434", manufacurer: "Hyundai", model: "veloster", year: "2012", km: "111,231", nickName: "tapuzi" },

        ]
    )



    useEffect(() => {
        const updateLocalStorage = () => {
            localStorage.setItem('statisticsCars', JSON.stringify(statisticsCars));
        };
        window.addEventListener('beforeunload', updateLocalStorage)
        return () => {
            window.removeEventListener('beforeunload', updateLocalStorage)
        };
    }, [statisticsCars]);




    return (
        <CarsContext.Provider value={{ statisticsCars }}>
            {props.children}

        </CarsContext.Provider>
    )
}





























