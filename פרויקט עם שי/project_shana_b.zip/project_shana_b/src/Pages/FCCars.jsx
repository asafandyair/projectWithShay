import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { CarsContext } from '../Context/CarsContextProvider';

import './Profile.css';

export default function FCCars() {
    const navigate = useNavigate();

    const { statisticsCars } = useContext(CarsContext);

    return (
        <div>
            <table className="user-table">
                <thead>
                    <tr>
                        <th>Car number</th>
                        <th>User code</th>
                        <th>Manufacturer</th>
                        <th>Model</th>
                        <th>Year</th>
                        <th>KM</th>
                        <th>Nick name</th>
                    </tr>
                </thead>
                <tbody>
                    {statisticsCars.map((car) => (
                        <tr key={car.carNumber}>
                            <td>{car.carNumber}</td>
                            <td>{car.userCode}</td>
                            <td>{car.manufacturer}</td>
                            <td>{car.model}</td>
                            <td>{car.year}</td>
                            <td>{car.km}</td>
                            <td>{car.nickName}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
