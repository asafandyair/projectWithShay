import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../Context/UserContextProvider';
import { StatisticsContext } from '../Context/StatisticsContextProvider';

import './Profile.css';

export default function FCProfile() {
  const navigate = useNavigate();

  const { currentUser, setloginOrProfile, setcurrentUser, setadminIsConnect } =
    useContext(UserContext);

  const { statisticsUsers } = useContext(StatisticsContext);

  const numUsers = statisticsUsers.length;
  const numNormalUsers = statisticsUsers.filter(user => user.userKind === "normal").length;
  const numAdminUsers = statisticsUsers.filter(user => user.userKind === "admin").length;
  const numMaleUsers = statisticsUsers.filter(user => user.gender === "male").length;
  const numFemaleUsers = statisticsUsers.filter(user => user.gender === "female").length;

  const btnPressLogOut = () => {
    setcurrentUser(null);
    setadminIsConnect(false);
    setloginOrProfile('/login');
    navigate('/');
  };

  return (
    <div>
      <table className="user-table">
        <thead>
          <tr>
            <th>Email</th>
            <th>Username</th>
            <th>Password</th>
            <th>User kind</th>
            <th>Gender</th>
            <th>Phone</th>
            <th>Birth date</th>
            <th>Birth join</th>
            <th>Name</th>
          </tr>
        </thead>
        <tbody>
          {statisticsUsers.map((user) => (
            <tr key={user.email}>
              <td>{user.email}</td>
              <td>{user.username}</td>
              <td>{user.password}</td>
              <td>{user.userKind}</td>
              <td>{user.gender}</td>
              <td>{user.phone}</td>
              <td>{user.birthDate}</td>
              <td>{user.birthJoin}</td>
              <td>{user.name}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="user-counter">
        Total users: {numUsers} | Normal users: {numNormalUsers} | Admin users: {numAdminUsers} | Male users: {numMaleUsers} | Female users: {numFemaleUsers}
      </div>

      <button onClick={btnPressLogOut}>Log out</button>
    </div>
  );
}
