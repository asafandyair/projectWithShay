import React, { useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import { UserContext } from '../Context/UserContextProvider'
import './Profile.css';


export default function FCProfile() {
    const navigate = useNavigate();

    const { currentUser, setloginOrProfile, setcurrentUser, setadminIsConnect } = useContext(UserContext)

    const btnPressLogOut = () => {
        setcurrentUser(null)
        setadminIsConnect(false)
        setloginOrProfile("/login")
        navigate("/")
    }


    return (
        <div>
                <div className="portfoliocard">
                    <div className="coverphoto"></div>
                    <div className="profile_picture"></div>
                    <div className="left_col">
                        <div>
                            <button onClick={btnPressLogOut}>Log out</button>
                        </div>

                    </div>
                    <div className="right_col">
                        <h2 className="name">{currentUser.name}</h2>
                        <ul className="contact_information">
                            <li className="mail">{currentUser.email} </li>

                        </ul>
                        
                    </div>

                </div>
        </div>
    )
}
