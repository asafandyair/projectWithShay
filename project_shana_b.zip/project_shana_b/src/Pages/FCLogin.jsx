import { Button, Snackbar, TextField } from '@mui/material'
import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { UserContext } from '../Context/UserContextProvider'


export default function FCLogin() {
  const [userEmailLogin, setuserNameLogin] = useState('')
  const [passwordLogin, setPasswordLogin] = useState('')
  const { users, setcurrentUser, fromLoginToCheckIfExist, setloginOrProfile, setadminIsConnect } = useContext(UserContext)
  const navigate = useNavigate()

  const [open, setOpen] = useState(false)
  const [message, setMessage] = useState('')

  // ---------- Click Register
  const btnClickRegister = () => {
    navigate('/register')
  }


  // ---------- Click ShowUsers
  const btnShowUsers = () => {
    console.log(users)
  }

  // ---------- Click Login
  const btnLoginPress = () => {
    let userCheckExist = fromLoginToCheckIfExist(userEmailLogin, passwordLogin)
    console.log(userCheckExist)
    if (userCheckExist !== null && userCheckExist !== undefined) {
      setMessage('Welcome')
      setOpen(true)
      setloginOrProfile("/profile")
      setcurrentUser(userCheckExist)
      navigate("/profile")
      if (userEmailLogin === "yair161643@gmail.com" || userEmailLogin === "asafmahluf2@gmail.com") {
        setadminIsConnect(true)
      }
    }
    else {
      setMessage("We don't know you")
      setOpen(true)
    }
  }

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return
    }
    setOpen(false)
  }


  return (




    <div style={{ width: '700px', background: "linear-gradient(to right, rgb(255, 255, 255), #835B00)" }}>

      <h1 style={{color:"lightblue"}}>𝓛𝓸𝓰𝓲𝓷</h1>

      <div style={{ display: 'flex', justifyContent: 'center', alignContent: 'center', alignItems: 'center', gap: '15px', flexDirection: 'column' }}>
        <TextField style={{ width: '50%' }} id="outlined-basic" label="Email" variant="outlined" onChange={(e) => setuserNameLogin(e.target.value)}></TextField>
        <TextField style={{ width: '50%' }} type={"password"} id="outlined-basic" label="Password" variant="outlined" onChange={(e) => setPasswordLogin(e.target.value)}></TextField>
      </div>



      <Button style={{ color: "white", fontSize: "30px" }} onClick={btnLoginPress}>Login</Button> <br />






      <Snackbar
        style={{ marginTop: '250px' }}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        open={open}
        autoHideDuration={1000}
        onClose={handleClose}
        message={message}
      />
    </div>
  )
}
