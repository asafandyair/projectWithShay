import React from 'react'
import { Route, Routes } from 'react-router-dom'
import FCLogin from '../Pages/FCLogin'
import FCProfile from '../Pages/FCProfile'




export default function FCRoutes() {
    return (
        <div style={{ margin: 20, fontSize: 25, color: 'red' }}>
            <Routes>
                <Route path='/' element={<FCLogin />} />
                <Route path='/profile' element={<FCProfile />} />
            </Routes>
        </div>
    )
}
